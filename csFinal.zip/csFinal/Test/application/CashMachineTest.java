package application;

import static org.junit.jupiter.api.Assertions.*;

import java.util.ArrayList;

import org.junit.Before;
import org.junit.jupiter.api.Test;

class CashMachineTest {
	
	@Before 
	public void setUp() {
		AccountData accountData = new AccountData(1111, "name", "email", 500);
		final ActionResult<AccountData> ars = ActionResult.success(accountData);
		ActionResult<AccountData> FAIL = ActionResult.fail("it did not succeed");
	}

	@Test
	void testLogin() {
		AccountData accountData = new AccountData(1111, "name", "email", 500);
		final ActionResult<AccountData> ARS = ActionResult.success(accountData);
		ActionResult<AccountData> ARF = ActionResult.fail("it did not succeed");
		CashMachine cashm = new CashMachine(new Bank());
		ActionResult<AccountData> ar = cashm.login(1000);
		assertTrue( ar.isSuccess()  );
	}
	
	@Test
	void testDeposit() {
		AccountData accountData = new AccountData(1111, "name", "email", 500);
		final ActionResult<AccountData> ARS = ActionResult.success(accountData);
		ActionResult<AccountData> ARF = ActionResult.fail("it did not succeed");
		CashMachine cashm = new CashMachine(new Bank());
		cashm.login(1000);
		ActionResult<AccountData> ar = cashm.deposit(1000);
		assertTrue( ar.isSuccess()  );
	}
	
	@Test
	void testDepositNegativeInput() {
		AccountData accountData = new AccountData(1111, "name", "email", 500);
		final ActionResult<AccountData> ARS = ActionResult.success(accountData);
		ActionResult<AccountData> ARF = ActionResult.fail("it did not succeed");
		CashMachine cashm = new CashMachine(new Bank());
		cashm.login(1000);
		ActionResult<AccountData> ar = cashm.deposit(-100);
		assertFalse( ar.isSuccess()  );
	}

	
	@Test
	void testWithdraw() {
		AccountData accountData = new AccountData(1111, "name", "email", 500);
		final ActionResult<AccountData> ARS = ActionResult.success(accountData);
		ActionResult<AccountData> ARF = ActionResult.fail("it did not succeed");
		CashMachine cashm = new CashMachine(new Bank());
		cashm.login(1000);
		ActionResult<AccountData> ar = cashm.withdraw(1000);
		assertFalse( ar.isSuccess()  );
	}
	
	@Test
	void testWithdraw2() {
		AccountData accountData = new AccountData(1111, "name", "email", 500);
		final ActionResult<AccountData> ARS = ActionResult.success(accountData);
		ActionResult<AccountData> ARF = ActionResult.fail("it did not succeed");
		CashMachine cashm = new CashMachine(new Bank());
		cashm.login(1000);
		ActionResult<AccountData> ar = cashm.withdraw(100);
		assertTrue( ar.isSuccess()  );
	}
	 
	@Test
	void testWithdrawNegativeInput() {
		AccountData accountData = new AccountData(1111, "name", "email", 500);
		final ActionResult<AccountData> ARS = ActionResult.success(accountData);
		ActionResult<AccountData> ARF = ActionResult.fail("it did not succeed");
		CashMachine cashm = new CashMachine(new Bank());
		cashm.login(1000);
		ActionResult<AccountData> ar = cashm.withdraw(-100);
		assertFalse( ar.isSuccess()  );
	}
	
	@Test
	void testListCustomers() {
		AccountData accountData = new AccountData(1111, "name", "email", 500);
		final ActionResult<AccountData> ARS = ActionResult.success(accountData);
		ActionResult<AccountData> ARF = ActionResult.fail("it did not succeed");
		CashMachine cashm = new CashMachine(new Bank());
		cashm.login(1000);
		ArrayList<String> tStrings = new ArrayList<String>(2);
		tStrings.add("Example2 Name");
		tStrings.add("Example1 Name");
		ActionResult<AccountData> ar = cashm.withdraw(-100);
		assertEquals( tStrings, cashm.listCustomers()  );
	}
	
	@Test
	void testCreateAccount() {
		AccountData accountData = new AccountData(1111, "name", "email", 500);
		final ActionResult<AccountData> ARS = ActionResult.success(accountData);
		ActionResult<AccountData> ARF = ActionResult.fail("it did not succeed");
		CashMachine cashm = new CashMachine(new Bank());
		cashm.login(1000);
		ActionResult<AccountData> ar = cashm.createAccount("name", "email", 1000);
		assertTrue( ar.isSuccess()  );
	}
	
	@Test
	void testRemoveAccount() {
		AccountData accountData = new AccountData(1111, "name", "email", 500);
		final ActionResult<AccountData> ARS = ActionResult.success(accountData);
		ActionResult<AccountData> ARF = ActionResult.fail("it did not succeed");
		CashMachine cashm = new CashMachine(new Bank());
		cashm.login(1000);
		cashm.removeAccount();
		ArrayList<String> tStrings = new ArrayList<String>(2);
		tStrings.add("Example2 Name");
		//tStrings.add("Example1 Name");
		assertEquals( tStrings, cashm.listCustomers()  );
	}
	
	@Test
	void testGetBalance() {
		AccountData accountData = new AccountData(1001, "name", "email", 500);
		AccountData accountData2 = new AccountData(1111, "name", "email", 500);
		assertEquals( accountData.getBalance(),  accountData2.getBalance()  );
	}
	

	
	



}
