package application;

import application.ActionResult;

/* From our research on example and ideas we saw a lot of people using Action Results
 * Action results are objects that do something depending on if the a success or fail happens
 * So we made a little list of things such as errors to show certain information if a fail
 * happens
 */


public class ActionResult<T> {

    private T data;
    private String errorMessage;

    private ActionResult(T data) {
        this.data = data;
    }

    private ActionResult(String errorMessage) {
        this.errorMessage = errorMessage;
    }

    public T getData() {
        return data;
    }

    public String getErrorMessage() {
        return errorMessage;
    }

    public boolean isSuccess() {
        return data != null;
    }

    public static <E> ActionResult<E> success(E data) {
        return new ActionResult<E>(data);
    }

    public static <E> ActionResult<E> fail(String errorMessage) {
        return new ActionResult<E>(errorMessage);
    }
}
