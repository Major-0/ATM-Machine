package application;

//We were planning on using different types of accounts, but we decided against it
//This class makes use of inheritance

public class BasicAccount extends Account {

    public BasicAccount(AccountData accountData) {
        super(accountData);
    }
}