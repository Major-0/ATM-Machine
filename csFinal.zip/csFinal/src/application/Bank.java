package application;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.Random;

/*
 * Bank class is where it holds the features of the bank
 * and what information it will hold and control, it will also help us access all our bank data
 */


public class Bank {

	private Map<Integer, Account> accounts = new HashMap<>();
	
	// Hashmap is to store account data and access account data with account ID

	public ActionResult<AccountData> createAccount(String name, String email, int deposit) {
		Random rand = new Random();
		int newId = rand.nextInt(10000);
		while (newId < 1000) {
			newId = newId * 10;
		}
		Account account = accounts.get(newId);
		while (account != null) {
			newId = rand.nextInt(10000);
			while (newId < 1000) {
				newId = newId * 10;
			}
			account = accounts.get(newId);
		}
		accounts.put(newId, new BasicAccount(new AccountData(newId, name, email, deposit)));
		account = accounts.get(newId);
		return ActionResult.success(account.getAccountData());
	}
	
	public ActionResult<AccountData> editAccount(int id, String name, String email) {
		Account oldAccount = accounts.get(id);
		int balance = oldAccount.getAccountData().getBalance();
		String newName = oldAccount.getAccountData().getName();
		String newEmail = oldAccount.getAccountData().getEmail();
		if (!name.isEmpty()) {  newName = name;  }
		if (!email.isEmpty()) {  newEmail = email;  }
		accounts.put(id, new BasicAccount(new AccountData(id, newName, newEmail, balance)));
		Account account = accounts.get(id);
		return ActionResult.success(account.getAccountData());
	}
	

	public Bank() {
		accounts.put(1000, new BasicAccount(new AccountData(1000, "Example1 Name", "example1@gmail.com", 500)));

		accounts.put(2000, new BasicAccount(new AccountData(2000, "Example2 Name", "example2@gmail.com", 200)));
	}
	
	// Another Action Result in case of errors for logging in with an id
	public ActionResult<AccountData> getAccountById(int id) {
		Account account = accounts.get(id);

		if (account != null) {
			return ActionResult.success(account.getAccountData());
		} else {
			return ActionResult.fail("No account found with Id: " + id);
		}
	}
	
	public void removeAccount(int id) {
		accounts.remove(id);		
	}

	// An action result for depositing money and will also print out information
	public ActionResult<AccountData> deposit(AccountData accountData, int amount) {
		Account account = accounts.get(accountData.getId());
		account.deposit(amount);

		return ActionResult.success(account.getAccountData());
	}

	// This is an action result for withdrawing where they can be a fail if withdrawing more then you have in your account
	public ActionResult<AccountData> withdraw(AccountData accountData, int amount) {
		Account account = accounts.get(accountData.getId());
		boolean ok = account.withdraw(amount);
		if (ok) {
			return ActionResult.success(account.getAccountData());
		} 
		return ActionResult.fail("Withdrawl of $" + amount + " not allowed \n" + "Account only contains $"
				+ account.getBalance());
	}
	
	public ArrayList<String> listCustomers() {
		ArrayList<String> names = new ArrayList<String>();
		for(Account data : accounts.values()) {
			names.add(data.getAccountData().getName());
		}
		return names;
		
	}
}
