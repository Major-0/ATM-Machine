package application;

import java.util.ArrayList;

/* The cash Machine class is for will be using the bank object
 * and use it access account information and perform deposits, withdraws 
 * We made a separate class so it would be easier to organize
 */


public class CashMachine {

    private final Bank bank;
    private AccountData accountData = null;

    public CashMachine(Bank bank) {
        this.bank = bank;
    }
    
    //Method for updating account data after a deposit or withdrawal
    private void update(AccountData data) {
    	accountData = data;
    }    

    //Login method checks if login was a success using action result
    public ActionResult<AccountData> login(int id) {
    	if (bank.getAccountById(id).isSuccess()) {
    		update(bank.getAccountById(id).getData());
    	}
    	return bank.getAccountById(id);
    }
    
    //method to list all customers
    public ArrayList<String> listCustomers() {
		return bank.listCustomers();
	}

    //method to create new account
    public ActionResult<AccountData> createAccount(String name, String email, int deposit) {
    	return bank.createAccount(name, email, deposit);
    }
    
    //method to edit account data
    public ActionResult<AccountData> editAccount(String name, String email) {
    	return bank.editAccount( accountData.getId(), name, email) ;  	
    }
    
    //method to deposit money 
    public ActionResult<AccountData> deposit(int amount) {
    	if (amount <= 0) {
    		return ActionResult.fail("Cannot deposit an amount \nless than or equal to zero");
    	}
    	update(bank.deposit(accountData, amount).getData());
    	return ActionResult.success(accountData);
    	
    }
    
    //method to remove an account
    public void removeAccount() {
        	bank.removeAccount(accountData.getId());
        	accountData = null;   
    }

    //method to withdraw money
    public ActionResult<AccountData> withdraw(int amount) {
    	if (amount <= 0) {
    		return ActionResult.fail("Cannot withdraw an amount \nless than or equal to zero");
    	}
        ActionResult<AccountData> withdrawResult = bank.withdraw(accountData, amount);
        if (withdrawResult.isSuccess()) {  update(withdrawResult.getData());  }
        return withdrawResult;
    }
    
    //method to return current balance
    public int getBalance() {  return accountData.getBalance();  }

    //method to log out of current account
    public void exit() {
        if (accountData != null) {
            accountData = null;
        }
    }

    //method to print account details
    @Override
    public String toString() {
        return accountData != null ? accountData.toString() : null ;
    }

   
    
}