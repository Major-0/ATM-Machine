package application;



import java.util.ArrayList;
import java.util.concurrent.TimeUnit;

import javafx.application.Application;
import javafx.application.Platform;
import javafx.geometry.Pos;
import javafx.stage.Stage;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Region;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;
import javafx.scene.text.Text;
import javafx.scene.text.TextAlignment;

//Appropriate error handling on all fields which require numerical input

public class Main extends Application {

	Stage window;
	Stage exitWindow;

	private Scene loginScene, newAccountScene, mainScene, startScene, messageScene, 
	customerListScene, editAccountScene, byeScene; // Scenes

	private TextField field = new TextField(); // text field for entering information in the main application
	private CashMachine cashMachine = new CashMachine(new Bank());
	
	
	//Creates Screen that the user sees when they open the application
	private Parent createStartScreen() {
		Region topSpacer = new Region();
		topSpacer.setPrefHeight(30);
		VBox buttonVbox = new VBox(15);
		buttonVbox.setPrefSize(300, 230);

		HBox loginButtonHbox = new HBox();
		loginButtonHbox.setAlignment(Pos.CENTER);
		Button loginButton = new Button("Login");
		loginButton.setOnAction(e -> {
			window.setScene(loginScene);
			window.setTitle("Login");
		});
		loginButtonHbox.getChildren().add(loginButton);

		HBox newAccountButtonHbox = new HBox();
		newAccountButtonHbox.setAlignment(Pos.CENTER);
		Button newAccountButton = new Button("Create Account");
		newAccountButton.setOnAction(e -> {
			window.setScene(newAccountScene);
			window.setTitle("Create New Account");
		});
		newAccountButtonHbox.getChildren().add(newAccountButton);
		
		HBox listCustomersButtonHbox = new HBox();
		listCustomersButtonHbox.setAlignment(Pos.CENTER);
		Button listCustomersButton = new Button("List Customers");
		listCustomersButton.setOnAction(e -> {
			customerListScene = new Scene(createCustomerList());
			customerListScene.getStylesheets().add(getClass().getResource("style.css").toExternalForm());
			window.setTitle("Customers");
			window.setScene(customerListScene);
		});
		listCustomersButtonHbox.getChildren().add(listCustomersButton);
		
		HBox exitButtonHbox = new HBox();
		exitButtonHbox.setAlignment(Pos.CENTER);
		Button exitButton = new Button("Exit");
		exitButton.setOnAction(e -> {
			byeScene = new Scene(createByeScreen());
			byeScene.getStylesheets().add(getClass().getResource("style.css").toExternalForm());
			window.setTitle("GoodBye");
			window.setScene(byeScene);			
			try {
				TimeUnit.SECONDS.sleep(3);
			} catch (InterruptedException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
			Platform.exit();
		});
		exitButtonHbox.getChildren().add(exitButton);

		buttonVbox.getChildren().addAll(topSpacer, loginButtonHbox, newAccountButtonHbox, listCustomersButtonHbox, exitButtonHbox);
		return buttonVbox;
	}
	
	//generates the goodbye message screen
	private Parent createByeScreen() {
		StackPane stackPane = new StackPane();
		stackPane.setPrefSize(300, 125);
		
		Region topSpacer = new Region();
		topSpacer.setPrefHeight(3);

		Text text = new Text("Thank You Valued Customer");
		text.setTextAlignment(TextAlignment.CENTER);
		stackPane.getChildren().addAll(text);
		StackPane.setAlignment(text, Pos.CENTER);
		
		return stackPane;
	}

	//generates a message screen.  This is used to alert the user of successful account removal
	private Parent createMessageScreen(String message) {
		
		StackPane stackPane = new StackPane();
		stackPane.setPrefSize(300, 125);
		VBox vbox = new VBox(15);
		vbox.setPrefSize(300, 150);
		
		Region topSpacer = new Region();
		topSpacer.setPrefHeight(3);
		

		HBox okButtonHbox = new HBox();
		okButtonHbox.setAlignment(Pos.CENTER);
		Button okButton = new Button("Main Menu");
		okButton.setOnAction(e -> {
			window.setScene(startScene);
			window.setTitle("ATM");
		});
		okButtonHbox.getChildren().add(okButton);

		Text text = new Text(message);
		text.setTextAlignment(TextAlignment.CENTER);
		stackPane.getChildren().addAll(topSpacer, text, okButtonHbox);
		StackPane.setAlignment(text, Pos.TOP_CENTER);
		StackPane.setAlignment(okButtonHbox, Pos.CENTER);
		vbox.getChildren().addAll(topSpacer, stackPane);
		return vbox;

		
	}
	
	//generates the customer list screen
	private Parent createCustomerList() {
	
		VBox vbox = new VBox(15);
		vbox.setPrefSize(600, 600);
		TextArea customerListTextArea = new TextArea(); 
		customerListTextArea.setEditable(false); 
		customerListTextArea.setMouseTransparent(true);
		customerListTextArea.setFocusTraversable(false);
		customerListTextArea.setPrefHeight(500); 
		customerListTextArea.setPrefWidth(600); 
		
		ArrayList<String> namesList = new ArrayList<String>();
		String names = "";
		namesList = cashMachine.listCustomers();
		for(String n : namesList) {
			names = names + n + "\n";
		}
		customerListTextArea.setText(names);

		HBox okButtonHbox = new HBox();
		okButtonHbox.setAlignment(Pos.CENTER);
		Button okButton = new Button("Main Menu");
		okButton.setOnAction(e -> {
			window.setScene(startScene);
			window.setTitle("ATM");
		});
		okButtonHbox.getChildren().add(okButton);

		
		vbox.getChildren().addAll(customerListTextArea, okButtonHbox);
		return vbox;
	}
	

	//generates the screen used to open a new account
	//Text fields are cleared once an account is created so that the next user
	//will not gain access to any sensitive information
	private Parent createNewAccountScreen() {
		VBox vbox = new VBox(15);
		vbox.setPrefSize(400, 250);
		Label nameLabel = new Label("Name: "); // label for name field on new account screen
		TextField nameTextField = new TextField(); // Text field for entering name on new account screen
		Label emailLabel = new Label("Email: ");
		TextField emailTextField = new TextField();
		Label initDepositLabel = new Label("Initial Deposit: ");
		TextField initDepositTextField = new TextField();

		Region sideSpacer1 = new Region();
		sideSpacer1.setPrefWidth(3);
		HBox nameHbox = new HBox();
		nameHbox.setAlignment(Pos.CENTER);
		nameHbox.getChildren().addAll(nameLabel, nameTextField, sideSpacer1);

		HBox emailHbox = new HBox();
		emailHbox.setAlignment(Pos.CENTER);
		emailHbox.getChildren().addAll(emailLabel, emailTextField);

		Region sideSpacer2 = new Region();
		sideSpacer2.setPrefWidth(45);
		HBox initDepositHbox = new HBox();
		initDepositHbox.setAlignment(Pos.CENTER);
		initDepositHbox.getChildren().addAll(initDepositLabel, initDepositTextField, sideSpacer2);

		HBox newAccountButtonHbox = new HBox();
		newAccountButtonHbox.setAlignment(Pos.CENTER);
		Button newAccountButton = new Button("Create Account");
		newAccountButton.setOnAction(e -> {

			String name = nameTextField.getText();
			nameTextField.clear();
			String email = emailTextField.getText();
			emailTextField.clear();
			String depositString = initDepositTextField.getText();
			if (depositString.isEmpty()) {  depositString = "0";  }
			int deposit = Integer.parseInt(depositString);
			initDepositTextField.clear();
			if (!name.isEmpty() && !email.isEmpty()) {
				ActionResult<AccountData> newAccountResult = cashMachine.createAccount(name, email, deposit);
				int accountId = newAccountResult.getData().getId();
				cashMachine.login(accountId);
				mainScene = new Scene(createMainMenu(cashMachine.toString()));
				mainScene.getStylesheets().add(getClass().getResource("style.css").toExternalForm());
				window.setTitle("Account Management");
				window.setScene(mainScene);
			} 
		});
		newAccountButtonHbox.getChildren().add(newAccountButton);

		Region topSpacer = new Region();
		topSpacer.setPrefHeight(5);
		vbox.getChildren().addAll(topSpacer, nameHbox, emailHbox, initDepositHbox, newAccountButtonHbox);
		return vbox;

	}

	//generates the login screen
	private Parent createLogin() {
		VBox vbox = new VBox(15);
		vbox.setPrefSize(300, 150); // set size of Vbox to (width, height)
		Label accountIdLabel = new Label("Account ID: "); // label for account Id field on login screen
		TextField accountIdTextField = new TextField(); // Text field for entering account Id on login screen
		HBox loginHbox = new HBox(15); // create horizontal stack for entering user id
		TextArea loginTextArea = new TextArea(); // text area for passing info to user on login screen
		loginTextArea.setEditable(false); // setting text area to be output only
		loginTextArea.setMouseTransparent(true);
		loginTextArea.setFocusTraversable(false);
		loginTextArea.setPrefHeight(120); // sets height of the TextArea to 120
		loginTextArea.setPrefWidth(300); // sets width of the TextArea to 300
		loginHbox.getChildren().add(accountIdLabel); // add label for account Id text field
		loginHbox.getChildren().add(accountIdTextField); // add text field for account Id
		loginHbox.setAlignment(Pos.CENTER); // set alignment for login Hbox
		
		Button backButton = new Button("Main Menu"); // Button to attempt login with provided ID
		backButton.setOnAction(e -> {
			accountIdTextField.clear();
			window.setTitle("ATM");
			window.setScene(startScene);
		});

		Button loginButton = new Button("Login"); // Button to attempt login with provided ID
		HBox loginButtonHbox = new HBox(25);
		loginButtonHbox.getChildren().addAll(backButton, loginButton);
		loginButtonHbox.setAlignment(Pos.CENTER); // center the login button

		loginButton.setOnAction(e -> {
			Boolean isNum = true;
			String idString = accountIdTextField.getText();
			int accountId = 0;
			if (idString.isEmpty()) { idString = "0";  }
			try {
				accountId = Integer.parseInt(idString);
			} catch (NumberFormatException exception) { 
				isNum = false;
				loginTextArea.setText("Only whole numbers are permitted");
			}	
			if (isNum) {
				ActionResult<AccountData> loginResult = cashMachine.login(accountId);
				if (loginResult.isSuccess()) {
					mainScene = new Scene(createMainMenu(cashMachine.toString()));
					mainScene.getStylesheets().add(getClass().getResource("style.css").toExternalForm()); // load css file to make text area transparent					window.setTitle("Account Management");
					window.setTitle("Account Management");
					window.setScene(mainScene);
					accountIdTextField.clear();
				} else {
					loginTextArea.setText(loginResult.getErrorMessage());				
				}
			}
			
		});
		
		Region topSpacer = new Region();
		topSpacer.setPrefHeight(50);
		vbox.getChildren().addAll(topSpacer, loginHbox, loginButtonHbox, loginTextArea);
		return vbox;	
	}

	//generates the main screen where users can manage their account
	private Parent createMainMenu(String accountData) {
		VBox vbox = new VBox(10);
		vbox.setPrefSize(600, 200);

		TextArea areaInfo = new TextArea();
		areaInfo.setPrefRowCount(4);
		areaInfo.setPrefColumnCount(50);
		areaInfo.setText(accountData);
		areaInfo.setEditable(false);
		areaInfo.setMouseTransparent(true);
		areaInfo.setFocusTraversable(false);
		

		TextArea actionResultTextArea = new TextArea();
		actionResultTextArea.setPrefRowCount(4);
		actionResultTextArea.setEditable(false);
		actionResultTextArea.setMouseTransparent(true);
		actionResultTextArea.setFocusTraversable(false);

		HBox infoHbox = new HBox();
		infoHbox.getChildren().addAll(areaInfo, actionResultTextArea);

		Button btnDeposit = new Button("Deposit");
		btnDeposit.setOnAction(e -> {
			boolean isNum = true;
			int amount = 0;
			String depositString = field.getText();
			field.clear();
			if (depositString.isEmpty()) {  depositString = "0";  }
			try {
			amount = Integer.parseInt(depositString);
			} catch (NumberFormatException nfe) { 
				isNum = false;
				actionResultTextArea.setText("Only whole numbers are permitted");
			} 
			if (isNum) { 
				ActionResult<AccountData> depositResult = cashMachine.deposit(amount);
				if (depositResult.isSuccess()) {  
					areaInfo.setText(cashMachine.toString());  
					actionResultTextArea.setText("Deposit of $" + amount + " was successfull");
				}
				else {  actionResultTextArea.setText(depositResult.getErrorMessage());  }
			}
		});

		Button btnWithdraw = new Button("Withdraw");
		btnWithdraw.setOnAction(e -> {
			boolean isNum = true;
			String withdrawString = field.getText();
			field.clear();
			if (withdrawString.isEmpty()) {  withdrawString = "0";  }
			int amount = 0;
			try {
			amount = Integer.parseInt(withdrawString);
			} catch (NumberFormatException nfe) { 
				isNum = false;
				actionResultTextArea.setText("Only whole numbers are permitted");
			} 
			if (isNum) { 
				ActionResult<AccountData> withdrawResult = cashMachine.withdraw(amount);
				areaInfo.setText(cashMachine.toString());
				if (withdrawResult.isSuccess()) {
					actionResultTextArea.setText("Withdrawl of $" + amount + " was successfull");
				} else {
					actionResultTextArea.setText(withdrawResult.getErrorMessage());
				} 
			}
		});

		Button btnExit = new Button("Logout");
		btnExit.setOnAction(e -> {
			cashMachine.exit();
			field.clear();
			areaInfo.clear();
			actionResultTextArea.clear();
			window.setTitle("ATM");
			window.setScene(startScene);
		});
		
		Button btnEditAccount = new Button("Edit Account");
		btnEditAccount.setOnAction(e -> {
			field.clear();
			areaInfo.clear();
			actionResultTextArea.clear();
			window.setTitle("Edit Account");
			editAccountScene = new Scene(createEditAccount());
			editAccountScene.getStylesheets().add(getClass().getResource("style.css").toExternalForm());
			window.setScene(editAccountScene);
		});

		Button btnRemoveAccount = new Button("Remove Account");
		btnRemoveAccount.setOnAction(e -> {
			cashMachine.removeAccount();
			field.clear();
			areaInfo.clear();
			actionResultTextArea.clear();

			window.setTitle("Account Status");
			messageScene = new Scene(createMessageScreen("Account Removed Successfully"));
			messageScene.getStylesheets().add(getClass().getResource("style.css").toExternalForm());
			window.setScene(messageScene);
		});

		HBox buttonHbox = new HBox(30);
		buttonHbox.getChildren().addAll(btnDeposit, btnWithdraw, btnExit, btnEditAccount, btnRemoveAccount);
		buttonHbox.setAlignment(Pos.CENTER);
		
		vbox.getChildren().addAll(infoHbox, field, buttonHbox);
		return vbox;
	}
	
	private Parent createEditAccount() {
		VBox vbox = new VBox(15);
		vbox.setPrefSize(400, 250);
		Label nameLabel = new Label("New Name: "); // label for name field on new account screen
		TextField nameTextField = new TextField(); // Text field for entering name on new account screen
		Label emailLabel = new Label("New Email: ");
		TextField emailTextField = new TextField();

		Region sideSpacer1 = new Region();
		sideSpacer1.setPrefWidth(3);
		HBox nameHbox = new HBox();
		nameHbox.setAlignment(Pos.CENTER);
		nameHbox.getChildren().addAll(nameLabel, nameTextField, sideSpacer1);

		HBox emailHbox = new HBox();
		emailHbox.setAlignment(Pos.CENTER);
		emailHbox.getChildren().addAll(emailLabel, emailTextField);

		
		HBox doneButtonHbox = new HBox();
		doneButtonHbox.setAlignment(Pos.CENTER);
		Button doneButton = new Button("Done");
		doneButton.setOnAction(e -> {

			String name = nameTextField.getText();
			nameTextField.clear();
			String email = emailTextField.getText();
			emailTextField.clear();
			ActionResult<AccountData> editResult = cashMachine.editAccount(name, email);				 
			window.setTitle("Account Management");
			mainScene = new Scene(createMainMenu(editResult.getData().toString()));
			mainScene.getStylesheets().add(getClass().getResource("style.css").toExternalForm());
			window.setScene(mainScene);
		});
		doneButtonHbox.getChildren().add(doneButton);

		Region topSpacer = new Region();
		topSpacer.setPrefHeight(5);
		vbox.getChildren().addAll(topSpacer, nameHbox, emailHbox, doneButtonHbox);
		return vbox;
		
	}
	
	

	@Override
	public void start(Stage primaryStage) throws Exception {
		startScene = new Scene(createStartScreen());
		loginScene = new Scene(createLogin());
		loginScene.getStylesheets().add(getClass().getResource("style.css").toExternalForm()); // load css file to make textArea transparent
		byeScene = new Scene(createByeScreen());
		byeScene.getStylesheets().add(getClass().getResource("style.css").toExternalForm());// load css file to make textArea transparent
		editAccountScene = new Scene(createEditAccount());
		newAccountScene = new Scene(createNewAccountScreen());
		newAccountScene.getStylesheets().add(getClass().getResource("style.css").toExternalForm());
		window = primaryStage;
		window.setTitle("ATM");
		window.setScene(startScene);
		window.setResizable(false);
		window.show();
	}

	public static void main(String[] args) {
		launch(args);
	}
}
