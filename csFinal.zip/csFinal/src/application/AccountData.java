package application;

/*
 * This is the information that each account will hold
 * Being ID, names, Email, Balance and be able to print out the data
 * 
 */


public final class AccountData {

    private final int id;
    private String name;
    private String email;
    
   

    private final int balance;
    
    public String[] splitName(String unsplitName) {
		return unsplitName.split(" ", 2); 
	}
    
    public void setName(String name) {
    	this.name = name;
    }
    
    public void setEmail(String email) {
    	this.email = email;
    }

    AccountData(int id, String name, String email, int balance) {
        this.id = id;
        this.name = name;
        this.email = email;
        this.balance = balance;
    }

    public int getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public String getEmail() {
        return email;
    }

    public int getBalance() {
        return balance;
    }

    @Override
    public String toString() {
        return "Account Id: " + id + '\n' +
                "Name: " + name + '\n' +
                "Email: " + email + '\n' +
                "Balance: $" + balance;
    }
}
